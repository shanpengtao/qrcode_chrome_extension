// 选项卡的数据源（如需增加可补充数据源及相对应的规则）
const segmentData = [
	{
		id: "segment0",
		label: "58同城",
		logo: "../images/58.png",
		isShowLogoPadding: true,
	},
	{
		id: "segment1",
		label: "58好借",
		logo: "../images/58haojie.png",
	},
	{
		id: "segment2",
		label: "58本地版",
		logo: "../images/58bendi.png",
	},
	{
		id: "segment3",
		label: "58安居客",
		logo: "../images/anjuke.png",
	},
	{
		id: "segment4",
		label: "好借微信小程序",
		logo: "../images/58.png",
		disabled: true,
		isShowLogoPadding: true,
	},
];

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	if (message.action === "getSegmentData") {
		sendResponse({ segmentData });
	}
});
